<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Laravel\Sanctum\HasApiTokens;

class Courses extends Model
{
    use HasApiTokens ,HasFactory;
    
    public $table = 'courses';
    
    protected $fillable=['name','description','price','image','status','course_type','level','detail_name','duration','location','column1',
                            'column2','column3','column4','seo_title','seo_keyword','seo_description'];
}
