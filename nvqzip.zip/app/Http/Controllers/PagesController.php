<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserQuery;
use Auth;

class PagesController extends Controller
{
    public function CustomerQuery(Request $request)
    {
        $input = $request->all();
        unset($input['_token']);
        
        if(!empty($input['name']) && !empty($input['email']) && !empty($input['phone']) && !empty($input['about_what']) &&
            !empty($input['message'])){
                
            $admin = \DB::table('admins')->first();
            $detail['name'] = $request->get('name') ?? '';
            $detail['email'] = $request->get('email') ?? '';
            $detail['phone'] = $request->get('phone') ?? ''; // Changed 'password' to 'phone'
            $detail['title'] = "Welcome to NVQ Web Application";
            $detail['body'] = "User raised a query to NVQ Web Application.";
            
            \Mail::send('email.user_queries', ['detail' => $detail], function ($message) use ($detail, $admin) {
                $message->to($admin->email)->subject($detail['title']);
            });
        
            UserQuery::create($input);
            return redirect()->back()->with('success', 'Your message sent to the administration');
        }
        else{
            return redirect()->back();
        }
    }
    
   
}
