<meta charset="UTF-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>NVQ & COURSES</title>
	
	
	@include('meta::manager', [
        'title' => $seo->seo_title ?? '',
        'keyword' => $seo->seo_keyword ?? '',
        'description' => $seo->seo_description ?? '',
   
    ])
	<!-- Favicon -->
	<link rel="icon" type="image/png" href="{{ asset('frontend/assets/images/1.png') }}">
	<!-- bootstrap CSS -->
	<link rel="stylesheet" href="{{ asset('frontend/assets/css/bootstrap.min.css') }}" type="text/css" media="all" />
	<!-- carousel CSS -->
	<link rel="stylesheet" href="{{ asset('frontend/assets/css/owl.carousel.min.css') }}" type="text/css" media="all" />	
	<!-- nivo-slider CSS -->
	<link rel="stylesheet" href="{{ asset('frontend/assets/css/nivo-slider.css') }}" type="text/css" media="all" />
	<!-- animate CSS -->
	<link rel="stylesheet" href="{{ asset('frontend/assets/css/animate.css') }}" type="text/css" media="all" />	
	<!-- animated-text CSS -->
	<link rel="stylesheet" href="{{ asset('frontend/assets/css/animated-text.css') }}" type="text/css" media="all" />	
	<!-- font-awesome CSS -->
	<link type="text/css" rel="stylesheet" href="{{ asset('frontend/assets/fonts/font-awesome/css/font-awesome.min.css') }}">
	<!-- font-flaticon CSS -->
	<link rel="stylesheet" href="{{ asset('frontend/assets/css/flaticon.css') }}" type="text/css" media="all" />	
	<!-- theme-default CSS -->
	<link rel="stylesheet" href="{{ asset('frontend/assets/css/theme-default.css') }}" type="text/css" media="all" />	
	<!-- meanmenu CSS -->
	<link rel="stylesheet" href="{{ asset('frontend/assets/css/meanmenu.min.css') }}" type="text/css" media="all" />	
	<!-- Main Style CSS -->
	<link rel="stylesheet"  href="{{ asset('frontend/assets/css/style.css') }}" type="text/css" media="all" />
	<!-- transitions CSS -->
	<link rel="stylesheet" href="{{ asset('frontend/assets/css/owl.transitions.css') }}" type="text/css" media="all" />
	<!-- venobox CSS -->
	<link rel="stylesheet" href="{{ asset('frontend/assets/css/venobox.css') }}" type="text/css" media="all" />
	<!-- widget CSS -->
	<link rel="stylesheet" href="{{ asset('frontend/assets/css/widget.css') }}" type="text/css" media="all" />
	<!-- settings CSS -->
	<link rel="stylesheet" href="{{ asset('frontend/assets/css/settings.css') }}" type="text/css" media="all" />
	<!-- responsive CSS -->
	<link rel="stylesheet" href="{{ asset('frontend/assets/css/responsive.css') }}" type="text/css" media="all" />
	<!-- modernizr js -->	
	<script type="text/javascript" src="{{ asset('frontend/assets/js/vendor/modernizr-3.5.0.min.js') }}"></script>
	
	
